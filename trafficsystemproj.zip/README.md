# CPS406-Traffic-Management-System
This is the group project for cps406

## Group # 4 Members:
Mathew P

Mohit S

Joseph Z

Abdullah H

Abdullah I

Aoun H

